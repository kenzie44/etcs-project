// Password code inspired by https://codepen.io/coder-aarush/pen/RwjRVvP

//this function takes user inputted password, checks against a value
//and returns if correct or not
function onSubmit() {

         if (document.getElementById('password').value == '362138') 
         {window.button2.style.display="inline"; }
         else{ alert('Access Denied, Please try again');}
     }
     
//this function takes user input on the search bar and checks the value
//this function is mostly to add the creepy text under the search bar,
//rather than search the website.
function onSearch()
{
   
    if(document.getElementById('search').value == "0000")
    {
        alert('correct');
    }
    else{ document.getElementById("search2").style.display = "inline";}
}  
     

